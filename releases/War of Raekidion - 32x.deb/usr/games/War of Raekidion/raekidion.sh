cd /usr/games/War\ of\ Raekidion
./raekidion
